import requests
import pytest

URL = 'https://api.pokemonbattle.ru/v2'
TOKEN = '8d93ce1a4a0cd2a53e8d8409e9faac36'
HEADER = {'Content-Type' : 'application/json', 'trainer_token' : TOKEN }
TRAINER_ID = '12962'

def test_status_code():
    response = requests.get(url= f'{URL}/trainers', params= {'trainer_id' : TRAINER_ID} )
    assert response.status_code == 200

def test_trainer_id_response():
    response_get = requests.get(url= f'{URL}/trainers', params= {'trainer_id' : TRAINER_ID})
    assert response_get.json()["data"][0]["trainer_name"] == 'Migera'



